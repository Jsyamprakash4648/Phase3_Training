using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hybridinheritance11
{
    public interface ICalculate
    {
         int ProjectMark { get; set; }


         void  CalculateUG();
       
    }
}