using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieTicketBooking
{
    public class Numbers
    {
    
        public void  addingdata()
        {
            CustomList<int> number=new CustomList<int>();

                    number.Add(1);
                    number.Add(2);
                    number.Add(3);
                    number.Add(4);
                    number.Add(5);
        }

        
        
       

        
        
        
        
    }
}